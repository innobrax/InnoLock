# Inno Lock — Teste BLE App Android + ESP32-C3

Data: 21/05/2026

Este pacote substitui o primeiro teste HTTP/Wi-Fi por um teste via **Bluetooth BLE**, adequado ao ESP32-C3.

O objetivo é simples: validar o paradigma de comunicação **celular Android → BLE → ESP32-C3 → comando de acionamento da trava**.

## Estrutura do pacote

```text
InnoLock_Teste_BLE_App_ESP32/
├─ android-app/                    Projeto Android nativo em Java
├─ esp32/InnoLock_Teste_BLE/        Firmware Arduino IDE para ESP32-C3
└─ docs/PROTOCOLO_BLE.md            Resumo do protocolo BLE usado
```

## Regra de identificação

O `device_id` do ESP32-C3 é o **MAC address** do próprio controlador, sem separadores.

Exemplo:

```text
MAC: A1:B2:C3:D4:E5:F6
Device ID: A1B2C3D4E5F6
Nome BLE anunciado: InnoLock_A1B2C3D4E5F6
```

O app também lê esse ID após conectar, usando o comando `ID?`.

## Firmware ESP32-C3

Arquivo:

```text
esp32/InnoLock_Teste_BLE/InnoLock_Teste_BLE.ino
```

### Biblioteca necessária

Na Arduino IDE, instale:

```text
NimBLE-Arduino 2.3.7 ou superior
```

### Pinos usados no teste

```text
GPIO4 = saída de acionamento para o BC547
GPIO5 = entrada de retorno/status da trava
```

Lógica elétrica usada no teste:

```text
GPIO4 HIGH = BC547 conduz = fio de comando da trava é aterrado
GPIO4 LOW  = comando desligado
GPIO5 LOW  = trava/êmbolo recolhido/destravado
```

## App Android BLE

Arquivo/pasta:

```text
android-app/
```

O app faz:

1. solicita permissões BLE;
2. escaneia dispositivos com serviço Nordic UART;
3. lista dispositivos `InnoLock_<MAC>`;
4. conecta ao ESP32-C3;
5. envia comandos simples:
   - `PULSE:1200`
   - `STATUS`
   - `ON`
   - `OFF`
   - `ID?`

## Como gerar o APK

1. Abra o **Android Studio**.
2. Selecione **Open**.
3. Abra a pasta:

```text
android-app
```

4. Aguarde a sincronização do Gradle.
5. Gere o APK em:

```text
Build > Build Bundle(s) / APK(s) > Build APK(s)
```

O arquivo será gerado em:

```text
android-app/app/build/outputs/apk/debug/app-debug.apk
```

## Passo a passo do teste

1. Grave o firmware `InnoLock_Teste_BLE.ino` no ESP32-C3.
2. Abra o Monitor Serial em 115200 bps.
3. Verifique o nome BLE anunciado, por exemplo:

```text
InnoLock_A1B2C3D4E5F6
```

4. Instale o APK no celular.
5. Ative o Bluetooth.
6. Abra o app **Inno Lock BLE**.
7. Toque em **Permissões BLE**.
8. Toque em **Escanear**.
9. Selecione o ESP32-C3 encontrado.
10. Toque em **Conectar**.
11. Toque em **ACIONAR TRAVA - PULSO 1,2s**.

## Observação importante

Este teste não possui senha, autenticação, criptografia de autorização, QR Code ou regras de negócio. Ele foi feito apenas para validar a conexão BLE e o acionamento básico.

A etapa posterior deve incluir:

- pareamento/autorização lógica por QR Code;
- armazenamento local de controladores autorizados;
- regra de limite de aberturas;
- lacre automático por tempo após fechamento da porta;
- confirmação física pelo retorno/status da trava;
- registro de eventos.
